package com.example.oldstocktrade;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.oldstocktrade.Model.Product;
import com.example.oldstocktrade.Model.ProductInHome;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;


public class ParticularProductActivity extends AppCompatActivity {
    private RecyclerView rv;
    private DatabaseReference df;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_feed);
        df= FirebaseDatabase.getInstance().getReference("Products");
        rv= (RecyclerView)findViewById(R.id.listViewProduct);
        rv.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerOptions<ProductInHome> options= new FirebaseRecyclerOptions.Builder<ProductInHome>()
                .setQuery(df, ProductInHome.class)
                .build();
        FirebaseRecyclerAdapter<ProductInHome, FindItemViewHolder> adapter= new FirebaseRecyclerAdapter<ProductInHome, FindItemViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FindItemViewHolder holder, int position, @NonNull ProductInHome product) {
//                Picasso.get().load(product.getUserImage()).into(holder.userImage);
//                Picasso.get().load(product.getProductImage()).into(holder.productImage);
//                Picasso.get().load(product.getProductImage()).into(holder.imageView);
                holder.productTime.setText(product.getProductTime());
                holder.productDetail.setText(product.getProductDetail());
                holder.productDistance.setText(product.getProductDistance());
                holder.productAddress.setText(product.getProductAddress());
                holder.productName.setText(product.getProductName());

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String id= getRef(position).getKey();
                        Intent partIntent= new Intent(ParticularProductActivity.this, ParticularPageActivity.class);
                        partIntent.putExtra("id", id);
                        startActivity(partIntent);
                    }
                });

            }

            @NonNull
            @Override
            public FindItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.product_view, parent, false);
                FindItemViewHolder viewHolder= new FindItemViewHolder(view);
                return viewHolder;
            }
        };

        rv.setAdapter(adapter);
//        adapter.startListening();
    }

    public static class FindItemViewHolder extends RecyclerView.ViewHolder{
        ImageView userImage, productImage, imageView;
        TextView productName, productAddress, productDistance, productDetail, productTime;


        public FindItemViewHolder(@NonNull View itemView) {
            super(itemView);
            userImage= itemView.findViewById(R.id.userImage);
            productName= itemView.findViewById(R.id.userName);
            productAddress= itemView.findViewById(R.id.productAddress);
            productDistance= itemView.findViewById(R.id.productDistance);
            productDetail= itemView.findViewById(R.id.productDetail);
            productTime= itemView.findViewById(R.id.productTime);
            productImage= itemView.findViewById(R.id.productImage);
            imageView= itemView.findViewById(R.id.imageView);
        }
    }
}
