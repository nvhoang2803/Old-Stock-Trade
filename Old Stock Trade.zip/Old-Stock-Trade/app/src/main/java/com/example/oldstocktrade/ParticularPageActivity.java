package com.example.oldstocktrade;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ParticularPageActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String receiveID= getIntent().getExtras().get("id").toString();
        Toast.makeText(this, "ID: "+ receiveID, Toast.LENGTH_SHORT).show();
    }
}
