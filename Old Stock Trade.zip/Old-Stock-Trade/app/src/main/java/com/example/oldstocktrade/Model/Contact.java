package com.example.oldstocktrade.Model;

public class Contact {
    String name;
    Integer img;

    public Contact(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Integer getImg() {
        return img;
    }
}