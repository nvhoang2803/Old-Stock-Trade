package com.example.oldstocktrade.Model;

import java.util.List;

public class Conversation {
    private String user1;
    private String user2;

    public String getUser1() {
        return user1;
    }

    public String getUser2() {
        return user2;
    }

}
