package com.example.oldstocktrade.Model;

public class ProductInHome {
    public ProductInHome() {
    }

    public String getUserImage() {
        return userImage;
    }

    public String getProductImage() {
        return productImage;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductAddress() {
        return productAddress;
    }

    public String getProductDistance() {
        return productDistance;
    }

    public String getProductDetail() {
        return productDetail;
    }

    public String getProductTime() {
        return productTime;
    }


    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductAddress(String productAddress) {
        this.productAddress = productAddress;
    }

    public void setProductDistance(String productDistance) {
        this.productDistance = productDistance;
    }

    public void setProductDetail(String productDetail) {
        this.productDetail = productDetail;
    }

    public void setProductTime(String productTime) {
        this.productTime = productTime;
    }

    String userImage;
    String productImage;
    String productName;
    String productAddress;
    String productDistance;
    String productDetail;
    String productTime;
}
