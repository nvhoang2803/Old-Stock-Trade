# Old-Stock-Trade
ID - Member <br>
18127102 - Nguyễn Văn Hoàng <br>
18127127 - Nguyễn Thị Thùy Linh <br>
18127160 - Nguyễn Lê Hoàng Nam <br>
18127220 - Nguyễn Nhật Thảo <br>
18127258 - Nguyễn Phạm Thanh Vy<br>

